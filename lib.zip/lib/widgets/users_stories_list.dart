import 'package:cached_network_image/cached_network_image.dart';
import 'package:eva_icons_flutter/eva_icons_flutter.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import '../controller/homescreeen_controller.dart';
import '../controller/story_controller.dart';
import '../screens/chat_screen.dart';
import '../app_theme.dart';
import '../models/user_model.dart';
import '../models/conversation_model.dart';
import '../models/story_model.dart';

import '../screens/story_camera_screen.dart';
import '../screens/view_story_screen.dart';

class HorizontalUserStoryList extends StatelessWidget {
  final HomeController homeController;
  final StoryController storyController = Get.put(StoryController());
  final String userId;

  HorizontalUserStoryList({required this.homeController, required this.userId});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Container(
      height: 120,
      padding: EdgeInsets.symmetric(horizontal: 10),
      child: StreamBuilder<List<ConversationModel>>(
        stream: homeController.getConversations(userId),
        builder: (context, snapshot) {
          if (!snapshot.hasData) return SizedBox();

          final conversations = snapshot.data!;
          final allUsers = [...{userId, ...conversations.map((e) => e.id)}];

          return ListView.builder(
            scrollDirection: Axis.horizontal,
            itemCount: allUsers.length,
            itemBuilder: (context, index) {
              final currentUserId = allUsers.elementAt(index);
              final isCurrentUser = currentUserId == userId;

              return FutureBuilder<UserModel>(
                future: homeController.getUserById(currentUserId),
                builder: (context, userSnapshot) {
                  if (!userSnapshot.hasData) return SizedBox();

                  final user = userSnapshot.data!;
                  final profileImageUrl = user.profileImage.isNotEmpty
                      ? user.profileImage
                      : 'https://i.pravatar.cc/150?u=${user.id}';

                  // التحقق مما إذا كانت البيانات موجودة في الـ cache قبل البدء بالتحميل
                  bool hasLoadedUserStories = GetStorage().read('${currentUserId}_stories_loaded') ?? false;

                  return StreamBuilder<List<StoryModel>>(
                    stream: hasLoadedUserStories
                        ? Stream.value([]) // تجنب إعادة تحميل البيانات إذا كانت محملة مسبقًا
                        : storyController.getUserStories(currentUserId),
                    builder: (context, storySnapshot) {
                      final hasStory = storySnapshot.hasData && storySnapshot.data!.isNotEmpty;

                      // إذا تم تحميل الـ stories لأول مرة، نقوم بتخزين الحالة في GetStorage
                      if (storySnapshot.hasData && !hasLoadedUserStories) {
                        GetStorage().write('${currentUserId}_stories_loaded', true);
                      }

                      return StreamBuilder<bool>(
                        stream: homeController.getUserOnlineStatus(currentUserId),
                        builder: (context, onlineSnapshot) {
                          final isOnline = onlineSnapshot.data ?? false;

                          return GestureDetector(
                            onTap: () async {
                              if (isCurrentUser) {
                                if (hasStory) {
                                  Get.to(() => StoryViewScreen(
                                    ownerId: currentUserId,
                                    stories: storySnapshot.data!,
                                    isOwner: true,
                                  ));
                                }
                              } else if (hasStory) {
                                Get.to(() => StoryViewScreen(
                                  ownerId: currentUserId,
                                  stories: storySnapshot.data!,
                                  isOwner: false,
                                ));
                              } else {
                                Get.to(() => ChatScreen(
                                  receiverId: user.id,
                                  receiverName: user.fullName,
                                  receiverUsername: user.username,
                                ));
                              }
                            },
                            child: Container(
                              width: 75,
                              margin: EdgeInsets.symmetric(horizontal: 6),
                              child: Column(
                                children: [
                                  Stack(
                                    children: [
                                      Container(
                                        padding: EdgeInsets.all(hasStory ? 2 : 0),
                                        decoration: BoxDecoration(
                                          shape: BoxShape.circle,
                                          gradient: hasStory
                                              ? LinearGradient(colors: [
                                            Colors.purpleAccent,
                                            Colors.orange,
                                          ])
                                              : null,
                                        ),
                                        child: CircleAvatar(
                                          radius: 45,
                                          backgroundImage: CachedNetworkImageProvider(profileImageUrl),
                                        ),
                                      ),
                                      if (isCurrentUser)
                                        Positioned(
                                          bottom: 7,
                                          right: 3,
                                          child: GestureDetector(
                                            onTap: () {
                                              Get.to(() => StoryCameraScreen());
                                            },
                                            // child: Icon(EvaIcons.plusCircle, size: 22, color: isDarkMode ? Colors.white : Colors.black),
                                            child: Container(
                                              decoration: BoxDecoration(
                                                color: isDarkMode ? Colors.black : Colors.white,
                                                shape: BoxShape.circle,
                                                border: Border.all(
                                                  color: isDarkMode ? Colors.black : Colors.white,
                                                ),
                                              ),
                                              width: 26,
                                              height: 26,
                                              child: Icon(EvaIcons.plusCircle, color: isDarkMode ? Colors.blue[700] : Colors.blue[700]),
                                            ),
                                          ),
                                        ),
                                      if (!isCurrentUser && isOnline)
                                        Positioned(
                                          bottom: 8,
                                          right: 4,
                                          child: Container(
                                            width: 17,
                                            height: 17,
                                            decoration: BoxDecoration(
                                              color: Colors.green,
                                              shape: BoxShape.circle,
                                              border: Border.all(
                                                color: isDarkMode ? Colors.black : Colors.white,
                                                width: 2.8,
                                              ),
                                            ),
                                          ),
                                        ),
                                    ],
                                  ),
                                  SizedBox(height: 5),
                                  Text(
                                    isCurrentUser ? 'Your Story' : user.fullName.split(' ').first,
                                    style: TextStyle(
                                      fontSize: 12,
                                      color: AppTheme.getTextColor(isDarkMode),
                                      overflow: TextOverflow.ellipsis,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        },
                      );
                    },
                  );
                },
              );
            },
          );
        },
      ),
    );
  }
}
