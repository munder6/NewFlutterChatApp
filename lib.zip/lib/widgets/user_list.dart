import 'package:cached_network_image/cached_network_image.dart';
import 'package:eva_icons_flutter/eva_icons_flutter.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controller/new_chat_controller.dart';
import '../screens/chat_screen.dart';
import '../app_theme.dart';

class UserList extends StatelessWidget {
  final NewChatController newChatController;

  UserList({required this.newChatController});

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Obx(() {
      if (newChatController.isLoading.value) {
        return Center(child: CircularProgressIndicator());
      }

      if (newChatController.usersList.isEmpty) {
        return Center(
          child: Text(
            "No users found",
            style: TextStyle(color: AppTheme.getTextColor(isDarkMode)),
          ),
        );
      }

      return Container(
        color: isDarkMode ? Colors.grey.shade900 : Colors.white,
        child: ListView.builder(
          itemCount: newChatController.usersList.length,
          itemBuilder: (context, index) {
            var user = newChatController.usersList[index];

            String profileImageUrl = user.profileImage.isNotEmpty
                ? user.profileImage
                : 'https://i.pravatar.cc/150?u=${user.id}';

            return Card(
              margin: EdgeInsets.symmetric(vertical: 4, horizontal: 10),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10),
              ),
              elevation: 0, // إزالة الظل
              color: isDarkMode ? Colors.grey[900] : Colors.white,
              child: ListTile(
                contentPadding: EdgeInsets.symmetric(vertical: 6, horizontal: 12), // تقليل ارتفاع الكارد

                leading: CircleAvatar(
                  radius: 22,
                  backgroundImage: CachedNetworkImageProvider(profileImageUrl),
                  backgroundColor: Colors.transparent,
                ),

                title: Row(
                  children: [
                    Flexible(
                      child: Text(
                        user.fullName,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: AppTheme.getTextColor(isDarkMode),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                    SizedBox(width: 6),
                    Text(
                      "•",
                      style: TextStyle(
                        fontSize: 18,
                        color: AppTheme.getTextColor(isDarkMode).withOpacity(0.6),
                      ),
                    ),
                    SizedBox(width: 6),
                    Flexible(
                      child: Text(
                        user.username,
                        style: TextStyle(
                          fontSize: 13,
                          color: AppTheme.getTextColor(isDarkMode).withOpacity(0.6),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ),
                  ],
                ),

                trailing: Icon(
                  EvaIcons.messageCircleOutline,
                  color: AppTheme.primaryColor(isDarkMode),
                ),

                onTap: () {
                  Get.to(() => ChatScreen(
                    receiverId: user.id,
                    receiverName: user.fullName,
                    receiverUsername: user.username,
                  ));
                },
              ),
            );
          },
        ),
      );
    });
  }
}
