import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:video_player/video_player.dart';
import '../controller/chat_controller.dart';
import '../controller/story_controller.dart';
import '../models/story_model.dart';
import '../app_theme.dart';
import '../widgets/story_viewers.dart';

class StoryViewScreen extends StatefulWidget {
  final String ownerId;
  final List<StoryModel> stories;
  final bool isOwner;

  StoryViewScreen({required this.ownerId, required this.stories, this.isOwner = false});

  @override
  _StoryViewScreenState createState() => _StoryViewScreenState();
}

class _StoryViewScreenState extends State<StoryViewScreen> {
  int currentIndex = 0;
  Timer? _timer;
  VideoPlayerController? _videoController;
  final StoryController storyController = Get.find();
  final TextEditingController _replyController = TextEditingController();


  @override
  void initState() {
    super.initState();
    _startStory();
  }

  void _startStory() async {
    final story = widget.stories[currentIndex];
    if (story.mediaType == 'video') {
      _videoController = VideoPlayerController.network(story.mediaUrl);
      await _videoController!.initialize();
      _videoController!.play();
      _videoController!.addListener(() => setState(() {}));
      _startTimer(story.duration);
    } else {
      _startTimer(story.duration);
    }

    // سجل المشاهدة فقط إن لم تكن القصة للمستخدم نفسه
    if (!widget.isOwner) {
      await storyController.markStoryAsViewed(widget.ownerId, story.storyId, GetStorage().read('user_id'));
    }
  }

  void _startTimer(int seconds) {
    _timer?.cancel();
    _timer = Timer(Duration(seconds: seconds), _nextStory);
  }

  void _nextStory() {
    if (currentIndex < widget.stories.length - 1) {
      setState(() {
        currentIndex++;
      });
      _disposeVideo();
      _startStory();
    } else {
      Get.back();
    }
  }

  void _previousStory() {
    if (currentIndex > 0) {
      setState(() {
        currentIndex--;
      });
      _disposeVideo();
      _startStory();
    }
  }

  void _disposeVideo() {
    _videoController?.pause();
    _videoController?.dispose();
    _videoController = null;
  }

  @override
  void dispose() {
    _disposeVideo();
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final story = widget.stories[currentIndex];

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          GestureDetector(
            onTapDown: (details) {
              final width = MediaQuery.of(context).size.width;
              if (details.globalPosition.dx < width / 2) {
                _previousStory();
              } else {
                _nextStory();
              }
            },
            child: Center(
              child: story.mediaType == 'image'
                  ? CachedNetworkImage(imageUrl: story.mediaUrl, fit: BoxFit.contain)
                  : (_videoController != null && _videoController!.value.isInitialized)
                  ? AspectRatio(
                aspectRatio: _videoController!.value.aspectRatio,
                child: VideoPlayer(_videoController!),
              )
                  : CircularProgressIndicator(),
            ),
          ),

          Positioned(
            top: 40,
            left: 10,
            right: 10,
            child: Row(
              children: widget.stories.map((s) {
                final index = widget.stories.indexOf(s);
                return Expanded(
                  child: Container(
                    margin: EdgeInsets.symmetric(horizontal: 2),
                    height: 3,
                    decoration: BoxDecoration(
                      color: index < currentIndex
                          ? Colors.white
                          : index == currentIndex
                          ? Colors.white.withOpacity(0.9)
                          : Colors.white.withOpacity(0.3),
                      borderRadius: BorderRadius.circular(10),
                    ),
                  ),
                );
              }).toList(),
            ),
          ),

          if (widget.isOwner)
            Positioned(
              bottom: 30,
              left: 20,
              right: 20,
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Row(
                    children: [
                      Icon(Icons.remove_red_eye, color: Colors.white),
                      SizedBox(width: 5),
                      Text(
                        widget.stories[currentIndex].viewedBy.length.toString(),
                        style: TextStyle(color: Colors.white),
                      ),
                    ],
                  ),
                  IconButton(
                    icon: Icon(Icons.expand_less, color: Colors.white),
                    onPressed: () {
                      showModalBottomSheet(
                        context: context,
                        backgroundColor: Colors.transparent,
                        isScrollControlled: true,
                        builder: (_) => StoryViewersBottomSheet(
                          viewerIds: widget.stories[currentIndex].viewedBy,
                        ),
                      );
                    },
                  )
                ],
              ),
            ),

          if (!widget.isOwner)
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: Container(
                padding: EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                color: Colors.black.withOpacity(0.8),
                child: Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _replyController,
                        style: TextStyle(color: Colors.white),
                        decoration: InputDecoration(
                          hintText: 'Reply to story ...',
                          hintStyle: TextStyle(color: Colors.white54),
                          border: InputBorder.none,
                        ),
                      ),
                    ),
                    IconButton(
                      icon: Icon(Icons.send, color: Colors.white),
                      onPressed: () async {
                        final text = _replyController.text.trim();
                        if (text.isNotEmpty) {
                          final currentStory = widget.stories[currentIndex];
                          final currentUserId = GetStorage().read('user_id');
                          final chatController = Get.find<ChatController>();

                          await chatController.sendMessage(
                            currentUserId,
                            widget.ownerId,
                            text,
                            'text',
                            replyToStoryUrl: currentStory.mediaUrl,
                            replyToStoryType: currentStory.mediaType,
                            replyToStoryId: currentStory.storyId,
                          );

                          _replyController.clear();
                          Get.snackbar("تم الإرسال", "تم إرسال ردك على الستوري");
                        }
                      },
                    ),
                  ],
                ),
              ),
            )

        ],
      ),
    );
  }
}
