import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker/image_picker.dart';
import 'package:path_provider/path_provider.dart';
import '../controller/story_controller.dart';

class StoryPreviewScreen extends StatefulWidget {
  final File imageFile;

  StoryPreviewScreen({required this.imageFile});

  @override
  _StoryPreviewScreenState createState() => _StoryPreviewScreenState();
}

class _StoryPreviewScreenState extends State<StoryPreviewScreen> {
  final StoryController storyController = Get.find();
  final box = GetStorage();

  List<_EditableTextItem> textItems = [];

  final GlobalKey _canvasKey = GlobalKey();

  void _addNewTextItem() {
    final controller = TextEditingController();
    final item = _EditableTextItem(
      controller: controller,
      position: Offset(100, 100),
      color: Colors.white,
      bgColor: Colors.black.withOpacity(0.7),
      fontSize: 24,
    );

    setState(() {
      textItems.add(item);
    });

    Future.delayed(Duration(milliseconds: 100), () {
      FocusScope.of(context).requestFocus(FocusNode());
    });
  }

  Future<File> _renderToImage() async {
    RenderRepaintBoundary boundary =
    _canvasKey.currentContext!.findRenderObject() as RenderRepaintBoundary;
    ui.Image image = await boundary.toImage(pixelRatio: 2.5);
    ByteData? byteData =
    await image.toByteData(format: ui.ImageByteFormat.png);
    Uint8List pngBytes = byteData!.buffer.asUint8List();

    final dir = await getTemporaryDirectory();
    final newPath = '${dir.path}/story_${DateTime.now().millisecondsSinceEpoch}.png';
    final newImage = File(newPath)..writeAsBytesSync(pngBytes);
    return newImage;
  }

  @override
  Widget build(BuildContext context) {
    final userId = box.read('user_id');

    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(
        children: [
          RepaintBoundary(
            key: _canvasKey,
            child: Stack(
              children: [
                Image.file(
                  widget.imageFile,
                  width: double.infinity,
                  height: double.infinity,
                  fit: BoxFit.cover,
                ),
                ...textItems.map((item) {
                  return Positioned(
                    left: item.position.dx,
                    top: item.position.dy,
                    child: GestureDetector(
                      onPanUpdate: (details) {
                        setState(() {
                          item.position += details.delta;
                        });
                      },
                      onTap: () async {
                        await _showTextEditDialog(item);
                      },
                      child: Container(
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                        color: item.bgColor,
                        child: Text(
                          item.controller.text,
                          style: TextStyle(
                            color: item.color,
                            fontSize: item.fontSize,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                    ),
                  );
                }).toList(),
              ],
            ),
          ),

          Positioned(
            bottom: 30,
            left: 20,
            right: 20,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                FloatingActionButton(
                  heroTag: "add_text",
                  onPressed: _addNewTextItem,
                  child: Icon(Icons.text_fields),
                  backgroundColor: Colors.deepPurple,
                ),
                ElevatedButton(
                  onPressed: () async {
                    final file = await _renderToImage();
                    await storyController.uploadStory(
                      userId: userId,
                      file: XFile(file.path),
                      isVideo: false,
                    );
                    Get.back();
                  },
                  child: Text("نشر الستوري"),
                  style: ElevatedButton.styleFrom(
                    backgroundColor: Colors.deepPurple,
                    shape: StadiumBorder(),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _showTextEditDialog(_EditableTextItem item) async {
    double currentFontSize = item.fontSize;
    Color currentColor = item.color;
    Color currentBgColor = item.bgColor;
    TextEditingController controller = item.controller;

    await Get.dialog(
      AlertDialog(
        backgroundColor: Colors.black87,
        title: Text("اكتب النص", style: TextStyle(color: Colors.white)),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            TextField(
              controller: controller,
              style: TextStyle(color: Colors.white),
              decoration: InputDecoration(
                hintText: "اكتب هنا...",
                hintStyle: TextStyle(color: Colors.white54),
              ),
            ),
            SizedBox(height: 20),
            Text("لون النص", style: TextStyle(color: Colors.white)),
            Wrap(
              spacing: 8,
              children: [
                Colors.white,
                Colors.black,
                Colors.red,
                Colors.green,
                Colors.blue,
                Colors.orange,
                Colors.purple,
                Colors.yellow,
              ].map((c) {
                return GestureDetector(
                  onTap: () => setState(() => item.color = c),
                  child: CircleAvatar(backgroundColor: c, radius: 15),
                );
              }).toList(),
            ),
            SizedBox(height: 10),
            Text("خلفية", style: TextStyle(color: Colors.white)),
            Wrap(
              spacing: 8,
              children: [
                Colors.transparent,
                Colors.black87,
                Colors.white70,
                Colors.orange,
                Colors.purpleAccent,
              ].map((c) {
                return GestureDetector(
                  onTap: () => setState(() => item.bgColor = c),
                  child: CircleAvatar(backgroundColor: c, radius: 15),
                );
              }).toList(),
            ),
            SizedBox(height: 10),
            Text("الحجم", style: TextStyle(color: Colors.white)),
            Slider(
              value: currentFontSize,
              min: 12,
              max: 64,
              onChanged: (val) {
                setState(() {
                  currentFontSize = val;
                  item.fontSize = val;
                });
              },
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Get.back(),
            child: Text("تم", style: TextStyle(color: Colors.white)),
          )
        ],
      ),
    );
  }
}

class _EditableTextItem {
  TextEditingController controller;
  Offset position;
  Color color;
  Color bgColor;
  double fontSize;

  _EditableTextItem({
    required this.controller,
    required this.position,
    required this.color,
    required this.bgColor,
    required this.fontSize,
  });
}
