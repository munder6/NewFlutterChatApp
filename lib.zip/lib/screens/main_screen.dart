import 'package:eva_icons_flutter/eva_icons_flutter.dart';
import 'package:flutter/material.dart';
import 'package:get_storage/get_storage.dart';
import 'package:ionicons/ionicons.dart';
import 'package:lottie/lottie.dart';
import '../app_theme.dart';
import 'home_screen.dart';
import 'new_chat_screen.dart';
import 'settings_screen.dart';

class MainScreen extends StatefulWidget {
  @override
  State<MainScreen> createState() => _MainScreenState();
}

class _MainScreenState extends State<MainScreen> {
  int _selectedIndex = 0;
  String? userId;
  bool isLoading = true;

  final List<Widget> _screens = [
    HomeScreen(),
    NewChatScreen(),
    SettingsScreen(),
  ];

  @override
  void initState() {
    super.initState();
    // اقرأ الـ userId من GetStorage مباشرة، إذا لم يكن موجوداً سنقوم بتحميله.
    userId = GetStorage().read('user_id');
    if (userId != null) {
      setState(() {
        isLoading = false;
      });
    } else {
      _loadUserId();
    }
  }

  Future<void> _loadUserId() async {
    await Future.delayed(Duration(milliseconds: 500));
    userId = GetStorage().read('user_id');
    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    if (isLoading) {
      return Scaffold(
        backgroundColor: AppTheme.backgroundColor(isDarkMode),
        body: Center(
          child: Lottie.asset("assets/lottie/splash.json", height: 60),
        ),
      );
    }

    if (userId == null) {
      return Scaffold(
        backgroundColor: AppTheme.backgroundColor(isDarkMode),
        body: Center(
          child: Text(
            "User not found",
            style: TextStyle(
              color: isDarkMode ? Colors.white : Colors.black,
              fontSize: 18,
            ),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppTheme.backgroundColor(isDarkMode),
      body: _screens[_selectedIndex],
      bottomNavigationBar: Container(
        height: 92,
        child: BottomNavigationBar(
          backgroundColor: isDarkMode ? Colors.grey[900] : Colors.grey[100],
          selectedItemColor: Colors.blue[800],
          unselectedItemColor: Colors.grey,
          currentIndex: _selectedIndex,
          onTap: (index) {
            setState(() {
              _selectedIndex = index;
            });
          },
          items: const [
            BottomNavigationBarItem(
              icon: Icon(EvaIcons.messageCircle),
              label: 'Chats',
            ),
            BottomNavigationBarItem(
              icon: Icon(EvaIcons.editOutline),
              label: 'New Chat',
            ),
            BottomNavigationBarItem(
              icon: Icon(Ionicons.settings_outline),
              label: 'Settings',
            ),
          ],
        ),
      ),
    );
  }
}
