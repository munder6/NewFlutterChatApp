import 'dart:ui';
import 'package:eva_icons_flutter/eva_icons_flutter.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:ionicons/ionicons.dart';
import 'package:lottie/lottie.dart';
import '../app_theme.dart';
import '../controller/homescreeen_controller.dart';
import '../widgets/conversation_list.dart';
import '../widgets/search_box.dart';
import 'new_chat_screen.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final HomeController homeController = Get.put(HomeController());
  final TextEditingController searchControllerText = TextEditingController();

  String searchQuery = "";
  String? userId;
  bool isLoading = true;

  @override
  void initState() {
    super.initState();

    // تأكد من عدم تحميل البيانات أكثر من مرة
    if (GetStorage().read('isUserLoaded') == true) {
      userId = GetStorage().read('user_id');
      isLoading = false;
    } else {
      _loadUserId();
    }
  }

  Future<void> _loadUserId() async {
    await Future.delayed(Duration(milliseconds: 500)); // شعور التحميل
    userId = GetStorage().read('user_id');
    GetStorage().write('isUserLoaded', true);
    setState(() {
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    bool isDarkMode = Theme.of(context).brightness == Brightness.dark;

    if (isLoading) {
      return Scaffold(
        backgroundColor: AppTheme.backgroundColor(isDarkMode),
        body: Center(
          child: Lottie.asset("assets/lottie/splash.json", height: 60),
        ),
      );
    }

    if (userId == null) {
      return Scaffold(
        backgroundColor: AppTheme.backgroundColor(isDarkMode),
        body: Center(
          child: Text(
            "User not found",
            style: TextStyle(
              color: isDarkMode ? Colors.white : Colors.black,
              fontSize: 18,
            ),
          ),
        ),
      );
    }

    return Scaffold(
      backgroundColor: AppTheme.backgroundColor(isDarkMode),
      body: Column(
        children: [
          // AppBar مخصص مع البلور
          Container(
            padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
            decoration: BoxDecoration(
              color: Colors.transparent, // الشفافية التامة
            ),
            child: Stack(
              children: [
                // تأثير البلور
                ClipRRect(
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 10.0, sigmaY: 10.0),
                    child: Container(
                      color: isDarkMode ? Colors.black.withOpacity(0.3) : Colors.white.withOpacity(0.3),
                    ),
                  ),
                ),
                // محتوى الـAppBar
                Column(
                  children: [
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(
                            "messenger",
                            style: TextStyle(
                              color: isDarkMode ? Colors.white : Colors.blue[700],
                              fontSize: 35,
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                          IconButton(
                            icon: Icon(Ionicons.create_outline, color: isDarkMode ? Colors.white : Colors.blue[700], size: 26,),
                            onPressed: () {
                              Get.to(() => NewChatScreen());
                            },
                          ),
                        ],
                      ),
                    ),

                  ],
                ),
              ],
            ),
          ),
          Expanded(
            child: Container(
              decoration: BoxDecoration(
                color: AppTheme.backgroundColor(isDarkMode), // التأكد من الخلفية المناسبة
                borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
              ),
              child: ConversationList(
                homeController: homeController,
                userId: userId!,
                searchQuery: searchQuery,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
