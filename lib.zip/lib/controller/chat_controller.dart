import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:get/get.dart';
import 'package:get_storage/get_storage.dart';
import 'package:image_picker/image_picker.dart';
import '../models/message_model.dart';

class ChatController extends GetxController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final box = GetStorage();
  final ImagePicker _picker = ImagePicker();

  // قائمة الرسائل
  var messages = <MessageModel>[].obs;

  // ✅ إرسال رسالة نصية أو وسائط
  Future<void> sendMessage(
      String senderId, String receiverId, String content, String contentType) async {
    try {
      String senderName = box.read('fullName') ?? 'Unknown Sender';
      String senderUsername = box.read('username') ?? 'UnknownUsername';

      String? receiverName = box.read('receiverName_\$receiverId');
      String? receiverUsername = box.read('receiverUsername_\$receiverId');

      if (receiverName == null || receiverUsername == null) {
        DocumentSnapshot receiverDoc =
        await _firestore.collection('users').doc(receiverId).get();
        if (receiverDoc.exists) {
          Map<String, dynamic>? receiverData =
          receiverDoc.data() as Map<String, dynamic>?;

          receiverName = receiverData?['fullName'] ?? 'Unknown Receiver';
          receiverUsername = receiverData?['username'] ?? 'UnknownUsername';

          box.write('receiverName_\$receiverId', receiverName);
          box.write('receiverUsername_\$receiverId', receiverUsername);
        }
      }

      String messageId = _firestore.collection('messages').doc().id;
      MessageModel message = MessageModel(
        id: messageId,
        senderId: senderId,
        receiverId: receiverId,
        content: content,
        contentType: contentType,
        isRead: false,
        timestamp: Timestamp.now(),
        receiverName: receiverName ?? 'Unknown Receiver',
        receiverUsername: receiverUsername ?? 'UnknownUsername',
      );

      await _firestore
          .collection('users')
          .doc(senderId)
          .collection('chats')
          .doc(receiverId)
          .collection('messages')
          .add(message.toMap());

      await _firestore
          .collection('users')
          .doc(receiverId)
          .collection('chats')
          .doc(senderId)
          .collection('messages')
          .add(message.toMap());

      DocumentReference receiverChatRef = _firestore
          .collection('users')
          .doc(receiverId)
          .collection('chats')
          .doc(senderId);
      await _firestore.runTransaction((transaction) async {
        DocumentSnapshot receiverChatSnapshot =
        await transaction.get(receiverChatRef);
        int currentUnreadMessages = receiverChatSnapshot.exists
            ? receiverChatSnapshot.get('unreadMessages') ?? 0
            : 0;

        transaction.set(receiverChatRef, {
          'lastMessage': content,
          'timestamp': Timestamp.now(),
          'receiverName': senderName,
          'receiverUsername': senderUsername,
          'unreadMessages': currentUnreadMessages + 1,
        }, SetOptions(merge: true));
      });

      DocumentReference senderChatRef = _firestore
          .collection('users')
          .doc(senderId)
          .collection('chats')
          .doc(receiverId);

      await senderChatRef.set({
        'lastMessage': content,
        'timestamp': Timestamp.now(),
        'receiverName': receiverName,
        'receiverUsername': receiverUsername,
        'unreadMessages': 0,
      }, SetOptions(merge: true));

    } catch (e) {
      print("Error sending message: \$e");
    }
  }

  // ✅ اختيار صورة أو فيديو وإرسالها
  Future<void> pickMedia(
      String senderId, String receiverId, ImageSource source, bool isVideo) async {
    try {
      final XFile? mediaFile = isVideo
          ? await _picker.pickVideo(source: source)
          : await _picker.pickImage(source: source);

      if (mediaFile != null) {
        File file = File(mediaFile.path);
        String fileName = DateTime.now().millisecondsSinceEpoch.toString();
        String fileType = isVideo ? "video" : "image";

        Reference storageRef =
        _storage.ref().child("chats/\$senderId/\$receiverId/\$fileName");

        UploadTask uploadTask = storageRef.putFile(file);
        TaskSnapshot snapshot = await uploadTask;
        String fileUrl = await snapshot.ref.getDownloadURL();

        await sendMessage(senderId, receiverId, fileUrl, fileType);
      }
    } catch (e) {
      print("Error picking media: \$e");
    }
  }

  // ✅ تحديث حالة الرسائل إلى "تمت مشاهدتها"
  Future<void> markMessagesAsRead(String senderId, String receiverId) async {
    try {
      var messagesRef = _firestore
          .collection('users')
          .doc(receiverId)
          .collection('chats')
          .doc(senderId)
          .collection('messages');

      var snapshot = await messagesRef.where('isRead', isEqualTo: false).get();

      for (var doc in snapshot.docs) {
        await doc.reference.update({'isRead': true});
      }

      await _firestore.collection('users').doc(senderId).collection('chats').doc(receiverId).update({
        'unreadMessages': 0,
      });
    } catch (e) {
      print("Error marking messages as read: \$e");
    }
  }

  // ✅ Stream لعرض الرسائل بشكل لحظي
  Stream<List<MessageModel>> getMessages(String senderId, String receiverId) {
    return _firestore
        .collection('users')
        .doc(senderId)
        .collection('chats')
        .doc(receiverId)
        .collection('messages')
        .orderBy('timestamp')
        .snapshots()
        .map((snapshot) => snapshot.docs
        .map((doc) => MessageModel.fromMap(doc.data()))
        .toList());
  }
}
