import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:get/get.dart';
import '../models/conversation_model.dart';

class HomeController extends GetxController {

  // قائمة المحادثات
  var conversations = <ConversationModel>[].obs;

  // دالة جلب المحادثات باستخدام Stream
  Stream<List<ConversationModel>> getConversations(String userId) {
    return FirebaseFirestore.instance
        .collection('users')
        .doc(userId)
        .collection('chats')
        .orderBy('timestamp', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) {
      var data = doc.data();
      data['id'] = doc.id; // 👈 مهم: لإرسال ID المستخدم الآخر (receiverId)
      return ConversationModel.fromMap(data);
    }).toList());
  }

}