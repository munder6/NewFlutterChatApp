import 'dart:io';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';
import '../models/story_model.dart';

class StoryController extends GetxController {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  final FirebaseStorage _storage = FirebaseStorage.instance;
  final picker = ImagePicker();

  var isUploading = false.obs;

  // ✅ Pick image or video
  Future<XFile?> pickMedia({required bool isVideo}) async {
    return await picker.pickImage(
      source: ImageSource.gallery,
      imageQuality: 80,
    );
  }

  // ✅ Upload media and create story
  Future<void> uploadStory({
    required String userId,
    required XFile file,
    required bool isVideo,
  }) async {
    isUploading.value = true;
    try {
      final ref = _storage.ref().child('stories/$userId/${DateTime.now().millisecondsSinceEpoch}.${file.path.split('.').last}');
      final uploadTask = await ref.putFile(File(file.path));
      final mediaUrl = await uploadTask.ref.getDownloadURL();

      int duration = isVideo ? await _getVideoDurationInSeconds(file.path) : 10;
      if (isVideo && duration > 15) {
        throw Exception("الفيديو أطول من 15 ثانية، غير مسموح رفعه.");
      }

      final story = StoryModel(
        storyId: '',
        mediaUrl: mediaUrl,
        mediaType: isVideo ? 'video' : 'image',
        createdAt: DateTime.now(),
        expireAt: DateTime.now().add(Duration(hours: 24)), // ✅ جديد
        duration: duration,
        viewedBy: [],
      );

      await _firestore.collection('users').doc(userId).collection('stories').add(story.toMap());
    } catch (e) {
      print('Error uploading story: \$e');
      rethrow;
    } finally {
      isUploading.value = false;
    }
  }

  // ✅ Get all stories of a user
  Stream<List<StoryModel>> getUserStories(String userId) {
    return _firestore
        .collection('users')
        .doc(userId)
        .collection('stories')
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snapshot) => snapshot.docs.map((doc) => StoryModel.fromMap(doc.data(), doc.id)).toList());
  }

  // ✅ Add viewer to story
  Future<void> markStoryAsViewed(String ownerId, String storyId, String viewerId) async {
    final ref = _firestore.collection('users').doc(ownerId).collection('stories').doc(storyId);
    final doc = await ref.get();
    if (!doc.exists) return;

    final viewedBy = List<String>.from(doc['viewedBy'] ?? []);
    if (!viewedBy.contains(viewerId)) {
      viewedBy.add(viewerId);
      await ref.update({'viewedBy': viewedBy});
    }
  }

  // ✅ Get video duration helper
  Future<int> _getVideoDurationInSeconds(String path) async {
    final controller = VideoPlayerController.file(File(path));
    await controller.initialize();
    final duration = controller.value.duration.inSeconds;
    await controller.dispose();
    return duration;
  }
}
